Authors
-------

Main developers
~~~~~~~~~~~~~~~

 * Emmanuel Blot <emmanuel.blot@free.fr>
 * Emmanuel Bouaziz <ebouaziz@free.fr>

Contributors
~~~~~~~~~~~~

 * Nikus-V
 * Dave McCoy
 * Adam Feuer
 * endlesscoil
 * humm (Fabien Benureau)
 * dlharmon
 * DavidWC
 * Sebastian
 * Anders (anders-code)
 * Andrea Concil
 * Darren Garnier
 * Michael Leonard
 * nopeppermint (Stefan)
 * hannesweisbach
 * Vianney le Clément de Saint-Marcq
 * Pete Schwamb
 * Will Richey
 * sgoadhouse
 * tavip (Octavian Purdila)
 * Tim Legrand
 * vestom
 * meierphil
 * etherfi
 * sgoadhouse
 * jnmacd
 * naushir

